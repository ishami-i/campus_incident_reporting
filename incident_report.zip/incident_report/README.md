# Campus Incident Reporting App

A cross-platform Flutter application for reporting and managing campus incidents (water, electricity, facility, safety, sanitation, and other) across campus areas like Enterprise Commons, Learning Commons, and Social Commons.

---

## 1. Firebase Firestore Integration

Incident reports and application state are synchronized with **Firebase Firestore**:
- **Collection**: `incidents`
- **Stored Attributes**:
  - `title`: Incident title
  - `description`: Detailed incident description
  - `category`: `water`, `electricity`, `facility`, `safety`, `sanitation`, or `other`
  - `status`: `submitted`, `in progress`, `resolved`, `closed`
  - `location`: Campus building & specific room/place
  - `studentEmail`: Email of reporting student
  - `image_url`: Openinary delivery URL (`https://cdn.openinary.dev/b/.../t/<path>`)
  - `created_at`: Server timestamp (`FieldValue.serverTimestamp()`)
  - `reasoning`: Optional status change resolution notes

---

## 2. Openinary Media Integration

File uploads and media delivery are integrated using **Openinary Cloud**:

- **API Host**: `https://cdn.openinary.dev`
- **Bucket ID**: `42a4c7a2-1798-4ac2-9028-571a59ab6a93`
- **Delivery Endpoint**: `https://cdn.openinary.dev/b/42a4c7a2-1798-4ac2-9028-571a59ab6a93/t/<path>`
- **Environment Key**: `openinary_key` in `.env` (secret key stored strictly in environment files and `.gitignore`d).

### Upload Workflow:
1. User picks/attaches an incident photo in `ReportingForm`.
2. `OpeninaryService` sends a multipart upload request to `https://cdn.openinary.dev/upload` signed with `openinary_key`.
3. Openinary returns the file path, formatted as the bare delivery URL: `https://cdn.openinary.dev/b/42a4c7a2-1798-4ac2-9028-571a59ab6a93/t/<path>`.
4. The delivery URL is saved in Firebase Firestore under the `image_url` field for rendering.

---

## 3. Authentication & Account Roles

- **Students**: Only students can sign up for new accounts. Student email addresses must follow the format: `name@alustudent.com`.
- **Staff**: Staff accounts are role-assigned. Staff logins use role-based email formats:
  - `facility@alueducation.com`
  - `security@alueducation.com`
  - `maintenance@alueducation.com`
  - `cleaning@alueducation.com`

### Default Staff Initial Passwords (Before Changing)

| Staff Role / Email | Default Initial Password |
|---|---|
| `facility@alueducation.com` | `StaffFacility123!` |
| `security@alueducation.com` | `StaffSecurity123!` |
| `maintenance@alueducation.com` | `StaffMaintenance123!` |
| `cleaning@alueducation.com` | `StaffCleaning123!` |
| `operations@alueducation.com` | `StaffOperations123!` |

*Note: Staff and students can change their passwords anytime via the Profile -> Change Password screen.*

---

## 4. Database & Relational Schema

In addition to Firestore, the project includes an offline relational schema (`database.sql` / SQLite `campus_incident.db`) containing tables for `role`, `category`, `status`, `user`, `incident`, and `staff`.
