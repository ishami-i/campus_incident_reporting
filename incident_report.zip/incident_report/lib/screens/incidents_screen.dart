import 'package:flutter/material.dart';
import 'package:incident_report/themes/app_theme.dart';
import 'package:incident_report/screens/reporting_screen.dart';
import 'package:incident_report/screens/incident_detail_screen.dart';

class IncidentsScreen extends StatelessWidget {
  final List<Map<String, dynamic>> incidents;

  const IncidentsScreen({super.key, this.incidents = const []});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).appColors;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'All Incidents',
          style: TextStyle(color: colors.text[950]),
        ),
        backgroundColor: colors.primary[500],
      ),
      body: incidents.isEmpty
          ? Center(
              child: Text(
                'No incidents reported yet.',
                style: TextStyle(color: colors.text[700]),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: incidents.length,
              itemBuilder: (context, index) {
                final incident = incidents[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  color: colors.background[100],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: colors.primary[500]?.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        incident['category'] == 'water'
                            ? Icons.water_drop
                            : incident['category'] == 'electricity'
                                ? Icons.electric_bolt
                                : Icons.business,
                        color: colors.primary[600],
                      ),
                    ),
                    title: Text(
                      incident['title'] ?? 'Untitled Incident',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: colors.text[950],
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 6.0),
                      child: Row(
                        children: [
                          _buildStatusBadge(incident['status'] ?? 'submitted'),
                          const Spacer(),
                          Text(
                            incident['date'] ?? 'Recently',
                            style: TextStyle(fontSize: 12, color: colors.text[700]),
                          ),
                        ],
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => IncidentDetailScreen(
                            incidentId: incident['id'] ?? '${index + 1}',
                            title: incident['title'] ?? 'Incident',
                            status: incident['status'] ?? 'submitted',
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: colors.accent[500],
        foregroundColor: colors.text[50],
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ReportingScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    if (status == 'in progress') {
      color = Colors.orange;
    } else if (status == 'resolved') {
      color = Colors.green;
    } else {
      color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }
}
