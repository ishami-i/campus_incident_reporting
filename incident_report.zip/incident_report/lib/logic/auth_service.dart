import 'package:firebase_auth/firebase_auth.dart';
import 'firestore_service.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Sign up user with Firebase Auth and save user profile in Firestore
  static Future<UserCredential?> signUp({
    required String email,
    required String password,
    required String name,
    required String role,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      if (credential.user != null) {
        await credential.user!.updateDisplayName(name);
      }
      await FirestoreService.saveUserProfile(
        email: email.trim(),
        name: name,
        role: role,
      );
      return credential;
    } catch (e) {
      await FirestoreService.saveUserProfile(
        email: email.trim(),
        name: name,
        role: role,
      );
      return null;
    }
  }

  /// Sign in user with Firebase Auth and retrieve registered name from Firestore / FirebaseAuth.
  /// Returns null if user is not registered in the database, requiring sign up.
  static Future<String?> signInAndGetName({
    required String email,
    required String password,
  }) async {
    String? resolvedName;

    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      if (credential.user?.displayName != null && credential.user!.displayName!.isNotEmpty) {
        resolvedName = credential.user!.displayName!;
      }
    } catch (_) {}

    // Check Firestore database if name not in Auth user profile
    final userDoc = await FirestoreService.getUserProfile(email);
    if (userDoc != null && userDoc['name'] != null && (userDoc['name'] as String).isNotEmpty) {
      resolvedName = userDoc['name'];
    }

    return resolvedName;
  }
}
