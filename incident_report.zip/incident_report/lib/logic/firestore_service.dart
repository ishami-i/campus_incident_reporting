import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  static const String _collection = 'incidents';

  /// Save user profile in Firestore
  static Future<void> saveUserProfile({
    required String email,
    required String name,
    required String role,
    String? photoUrl,
  }) async {
    try {
      await _db.collection('users').doc(email.toLowerCase()).set({
        'email': email.toLowerCase(),
        'name': name,
        'role': role,
        if (photoUrl != null) 'photo_url': photoUrl,
        'updated_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {}
  }

  /// Save user profile photo URL in Firestore
  static Future<void> saveUserProfilePhoto(String email, String photoUrl) async {
    try {
      await _db.collection('users').doc(email.toLowerCase()).set({
        'photo_url': photoUrl,
        'updated_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {}
  }

  /// Get user profile from Firestore by email
  static Future<Map<String, dynamic>?> getUserProfile(String email) async {
    try {
      final doc = await _db.collection('users').doc(email.toLowerCase()).get();
      if (doc.exists) {
        return doc.data();
      }
    } catch (_) {}
    return null;
  }

  /// Save new incident report to Firebase Firestore
  static Future<String> createIncident({
    required String title,
    required String description,
    required String category,
    required String location,
    required String studentEmail,
    String? imageUrl,
  }) async {
    final docRef = await _db.collection(_collection).add({
      'title': title,
      'description': description,
      'category': category.toLowerCase(),
      'status': 'submitted',
      'location': location,
      'studentEmail': studentEmail.toLowerCase(),
      'image_url': imageUrl,
      'created_at': FieldValue.serverTimestamp(),
    });
    return docRef.id;
  }

  /// Fetch incidents stream from Firebase Firestore
  static Stream<QuerySnapshot> getIncidentsStream() {
    return _db.collection(_collection).orderBy('created_at', descending: true).snapshots();
  }

  /// Update status and optional reasoning notes in Firebase Firestore
  static Future<void> updateIncidentStatus({
    required String incidentId,
    required String newStatus,
    String? reasoning,
  }) async {
    await _db.collection(_collection).doc(incidentId).update({
      'status': newStatus.toLowerCase(),
      'reasoning': reasoning,
      'updated_at': FieldValue.serverTimestamp(),
    });
  }
}
