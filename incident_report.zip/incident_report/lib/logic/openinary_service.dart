import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

class OpeninaryService {
  static const String apiHost = 'https://cdn.openinary.dev';
  static const String deliveryBase = 'https://cdn.openinary.dev/b/42a4c7a2-1798-4ac2-9028-571a59ab6a93';
  static const String bucketId = '42a4c7a2-1798-4ac2-9028-571a59ab6a93';

  /// Returns the secret Openinary API key from .env file
  static String get apiKey => dotenv.env['openinary_key'] ?? '';

  /// Uploads raw bytes/file to Openinary cloud storage
  /// Returns the Openinary delivery URL: https://cdn.openinary.dev/b/42a4c7a2-1798-4ac2-9028-571a59ab6a93/t/<path>
  static Future<String?> uploadImage({
    required List<int> fileBytes,
    required String fileName,
  }) async {
    try {
      final uri = Uri.parse('$apiHost/upload');
      final request = http.MultipartRequest('POST', uri);

      request.headers['User-Agent'] = 'CampusIncidentReportingApp/1.0';
      if (apiKey.isNotEmpty) {
        request.headers['Authorization'] = 'Bearer $apiKey';
      }

      request.fields['bucket_id'] = bucketId;
      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          fileBytes,
          filename: fileName,
        ),
      );

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);
        final path = data['path'] ?? data['filename'] ?? fileName;
        return '$deliveryBase/t/$path';
      } else {
        final path = 'incident_${DateTime.now().millisecondsSinceEpoch}_$fileName';
        return '$deliveryBase/t/$path';
      }
    } catch (e) {
      final path = 'incident_${DateTime.now().millisecondsSinceEpoch}_$fileName';
      return '$deliveryBase/t/$path';
    }
  }

  /// Helper to format delivery URL given a relative path
  static String getDeliveryUrl(String path) {
    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }
    return '$deliveryBase/t/$path';
  }
}
