class FormValidator {
  static String? validateEmail(String? value, {bool isSignup = false}) {
    if (value == null || value.trim().isEmpty) {
      return 'Please enter an email address';
    }
    final email = value.trim().toLowerCase();

    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(email)) {
      return 'Please enter a valid email address (e.g., name@alustudent.com)';
    }
    
    if (isSignup) {
      if (!email.endsWith('@alustudent.com')) {
        return 'Only students can sign up. Email must end with @alustudent.com';
      }
    } else {
      if (!email.endsWith('@alustudent.com') && !email.endsWith('@alueducation.com')) {
        return 'Enter a valid student (@alustudent.com) or staff (@alueducation.com) email';
      }
    }
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  static String? validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Please enter your full name';
    }
    if (value.trim().length < 2) {
      return 'Full name must be at least 2 characters long';
    }
    return null;
  }

  static String? validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return 'Please enter $fieldName';
    }
    return null;
  }
}
