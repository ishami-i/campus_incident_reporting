import 'package:flutter/material.dart';
import 'package:incident_report/themes/app_theme.dart';
import 'package:incident_report/screens/incident_detail_screen.dart';

class RecentReports extends StatelessWidget {
  final List<Map<String, dynamic>> reports;

  const RecentReports({super.key, this.reports = const []});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).appColors;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Reports',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: colors.text[950],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        reports.isEmpty
            ? Container(
                padding: const EdgeInsets.all(24),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: colors.background[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'No recent reports found.',
                  style: TextStyle(color: colors.text[700]),
                ),
              )
            : ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: reports.length,
                itemBuilder: (context, index) {
                  final report = reports[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    color: colors.background[100],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      leading: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: colors.primary[500]?.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          report['category'] == 'water'
                              ? Icons.water_drop
                              : report['category'] == 'electricity'
                                  ? Icons.electric_bolt
                                  : Icons.business,
                          color: colors.primary[600],
                        ),
                      ),
                      title: Text(
                        report['title'] ?? 'Untitled Incident',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: colors.text[950],
                        ),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6.0),
                        child: Row(
                          children: [
                            _buildStatusBadge(report['status'] ?? 'submitted'),
                            const Spacer(),
                            Text(
                              report['date'] ?? 'Recently',
                              style: TextStyle(fontSize: 12, color: colors.text[700]),
                            ),
                          ],
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => IncidentDetailScreen(
                              incidentId: report['id'] ?? '${index + 1}',
                              title: report['title'] ?? 'Incident',
                              status: report['status'] ?? 'submitted',
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
      ],
    );
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    if (status == 'in progress') {
      color = Colors.orange;
    } else if (status == 'resolved') {
      color = Colors.green;
    } else {
      color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }
}
